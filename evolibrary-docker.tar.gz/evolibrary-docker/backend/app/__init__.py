"""
🦠 Evolibrary - Backend Application
"Evolve Your Reading"
By CookieBytes Technologies
"""

__version__ = "0.1.0"
__author__ = "CookieBytes Technologies"
__mascot__ = "Morpho 🦠"
